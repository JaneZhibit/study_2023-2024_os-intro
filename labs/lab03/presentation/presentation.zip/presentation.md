---
## Front matter
lang: ru-RU
title: Лабораторная работа №3
subtitle: Работа с Markdown
author:
  - Жибицкая Евгения Дмитриевна
institute:
  - Российский университет дружбы народов, Москва, Россия
## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
 
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
---



# Цель

## Цель

Приобретение навыков по работе с Markdown.


# Начало работы
:::::::::::::: {.columns align=center}
::: {.column width="50%"}
Предварительно устанавливаем Markdown и  Texlive, затем переходим в каталог и открываем файл md.

:::
::: {.column width="50%"}

![Открытие файла](image/1.png)

:::
::::::::::::::
## Загрузка шрифтов
:::::::::::::: {.columns align=center}
::: {.column width="50%"}

![Шрифты](image/2.png)
:::
::::::::::::::

## Заполнение
:::::::::::::: {.columns align=center}
::: {.column width="50%"}

![Описание хода работы, установка ссылок на изображения](image/3.png)
:::
::::::::::::::

## Скриншоты
:::::::::::::: {.columns align=center}
::: {.column width="50%"}

![Загрузка скриншотов в отдельную папку image](image/4.png)
:::
::::::::::::::

## Сохранение работы

:::::::::::::: {.columns align=center}
::: {.column width="50%"}

![Ввод make, создание отчета в формате pdf и docx](image/5.png)
:::
::::::::::::::


# Вывод

## Вывод

В ходе работы была освоена работа с системой Markdown, создан отчет для 2 лабораторной работы.




